/*******************************************************************************
* FileName:         Graph.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2023/04/29 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #12
*******************************************************************************/

#include "Graph.h"

Graph::Graph(int max_v){

}

Graph::~Graph(){

}

void Graph::addedge(int s, int t, int w){

}

int Graph::getV(){

}

int* Graph::topological(){

}

int* Graph::ka(){

}