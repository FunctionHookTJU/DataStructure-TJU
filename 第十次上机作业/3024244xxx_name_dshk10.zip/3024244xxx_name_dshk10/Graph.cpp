/*******************************************************************************
* FileName:         Graph.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Version:          v1.0
* Description:      Data Structure Experiment #10
*******************************************************************************/

#include "Graph.h"


Graph::Graph(int v){

}

Graph::~Graph(){

}

void Graph::addedge(int s, int t, int w){

}

int Graph::getInDegree(int v){

}

int Graph::getOutDegree(int v){

}

int Graph::access(int s, int t){

}

int Graph::getDist(int s, int t){

}