/*******************************************************************************
* FileName:         Haffman.h
* Author:           Name
* Student Number:   3024244XXX
* Date:             2025/11/16
* Version:          v1.1
* Description:      Data Structure Experiment #7
*******************************************************************************/

#ifndef HUFFMANTREE_H
#define HUFFMANTREE_H

#include <string>
using std::string;

class HuffmanTree{
private:
public:
    /**
     *  构造函数
        @name HuffmanTree(const int* Table)
        @param arg1 数字出现的频度表
        @return
        注意： 要求树的左孩子为权制较小的编码，左孩子的二进制编号为0
    */
    HuffmanTree(const int* Table);

    /**
     *  析构函数
        @name ~HuffmanTree()
        @param 
        @return
    */
    ~HuffmanTree();

    /**
     *  获取message的霍夫曼编码
        @name string Encode(string)
        @param  arg1 待编码待字符串
        @return 对应的霍夫曼编码
    */
    string Encode(string message);


    /**
     *  获取message的霍夫曼解码
        @name string Decode(stirng)
        @param 
        @return 解码出的内容
    */
    string Decode(string message);
};

#endif