/*******************************************************************************
* FileName:         Haffman.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2025/11/13
* Version:          v1.1
* Description:      Data Structure Experiment #7
*******************************************************************************/

#include "Huffman.h"

HuffmanTree::HuffmanTree(const int* Table){

}

HuffmanTree::~HuffmanTree(){

}

string HuffmanTree::Encode(string message){

}

string HuffmanTree::Decode(string message){
}